import registerStyles from "./register.module.css";

function Register() {
  return (
    <section>

    </section>
  );
}

export default Register;
