import cn from "classnames";
import inputBankStyles from "./input-bank.module.css";

function InputBank({ name, placeholder, validation, className, valuess, setValuess, ...props }) {
  const { values, errors, handleChange } = validation;

  const handleChangee = (e) => {
    const target = e.target;
    const value = target.value;
    const namee = target.name;
    setValuess({...valuess, [name]: [...[namee] = value ]});
    // setErrors({ ...errors, [name]: target.validationMessage });
    // setIsValid(target.closest("form").checkValidity());
  };

  return (
    <fieldset className={inputBankStyles.fields}>
      <label htmlFor="standard-select"></label>
      {/* <div className="select"> */}
      <select id="standard-select" onChange={handleChangee} name="bank">
        <option value="Hapoalim">Hapoalim</option>
        <option value="Leumi">Leumi</option>
        <option value="Mizrahi-Tefahot">Mizrahi-Tefahot</option>
        <option value="HaBeinleumi">HaBeinleumi</option>
        <option value="Discount">Discount</option>
      </select>
      {/* <span class="focus"></span>
    </div> */}
      <label>
        <input
          type="text"
          placeholder="Branch"
          onChange={handleChangee}
          name="branch"
        />
        <input
          type="text"
          placeholder="Number"
          onChange={handleChangee}
          name="number"
        />
      </label>

      {/* <Input
      validation={validation}
      className={accountsStyles.input}
      name="name"
      placeholder="First name"
      required
    /> */}
    </fieldset>
  );
}

export default InputBank;
