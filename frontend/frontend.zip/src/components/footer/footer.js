import footerStyles from "./footer.module.css";

function Footer() {
  return (
    <footer></footer>
  );
}

export default Footer;
