import loanStyles from "./loan.module.css";

function Loan() {
  return (
    <section>

    </section>
  );
}

export default Loan;
